# OXIDE HEADLOCK — protótipo Android

Este repositório contém a primeira versão visual do painel Android.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta `OxideHeadlock` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute em um aparelho Android ou emulador.

## Limites desta versão
É somente um protótipo de interface. Os botões são demonstrativos: não fazem a mira acompanhar inimigos, não leem memória/dados internos do Oxide e não mostram jogadores ou loot através de paredes. Não inclui mecanismo de cheat nem integração com o jogo.

Para gerar um APK de demonstração no Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Compilar pelo navegador (GitHub Actions)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta para a branch `main`.
2. Abra a aba **Actions** e permita executar workflows, se solicitado.
3. Selecione **Build OXIDE HEADLOCK demo APK** e toque em **Run workflow** (ou aguarde o build após enviar os arquivos).
4. Quando terminar com sucesso, abra a execução e baixe o artefato `oxide-headlock-demo-apk`.
5. Extraia o ZIP do artefato para encontrar `app-debug.apk`.

O workflow usa Java 17 e Gradle 8.9 no runner do GitHub. O APK gerado continua sendo apenas a demonstração de interface descrita acima.

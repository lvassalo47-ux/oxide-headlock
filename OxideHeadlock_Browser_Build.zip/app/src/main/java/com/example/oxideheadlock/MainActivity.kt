package com.example.oxideheadlock

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 14)
    private val card = Color.rgb(27, 27, 31)
    private val red = Color.rgb(255, 55, 55)
    private val muted = Color.rgb(165, 165, 172)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(20))
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "OXIDE  HEADLOCK"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        content.addView(title, params(-1, -2))
        val subtitle = TextView(this).apply {
            text = "ANDROID CONTROL PANEL  •  DEMO 0.1"
            textSize = 10f
            letterSpacing = 0.14f
            setTextColor(red)
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(22))
        }
        content.addView(subtitle)

        section(content, "AIM ASSIST")
        toggleCard(content, "HEADLOCK", "Configuração demonstrativa de assistência de mira.")
        toggleCard(content, "HEAD PRIORITY", "Opção visual para priorizar a cabeça.")
        section(content, "VISUAL")
        toggleCard(content, "PLAYER ESP", "Demonstração de identificação de jogadores.")
        toggleCard(content, "LOOT ESP", "Demonstração de localização de itens.")
        section(content, "CONFIGURAÇÕES")
        val distance = TextView(this).apply {
            text = "DISTÂNCIA  •  DEMONSTRAÇÃO"
            setTextColor(Color.WHITE); textSize = 13f
            setPadding(dp(15), dp(12), dp(15), 0)
        }
        content.addView(distance)
        val seek = SeekBar(this).apply { max = 500; progress = 150 }
        content.addView(seek, params(-1, -2).apply { setMargins(dp(12), 0, dp(12), dp(12)) })
        val note = TextView(this).apply {
            text = "Este é um protótipo de interface. Os controles não alteram a mira, não leem dados do Oxide e não revelam jogadores ou loot através de paredes."
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(card)
        }
        content.addView(note, params(-1, -2).apply { topMargin = dp(12) })
        val footer = TextView(this).apply {
            text = "OXIDE HEADLOCK  •  PROTÓTIPO"
            textSize = 10f; setTextColor(muted); gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, dp(8))
        }
        content.addView(footer)

        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
    }

    private fun section(parent: LinearLayout, name: String) {
        val t = TextView(this).apply {
            text = name
            textSize = 11f
            letterSpacing = 0.16f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(2), dp(20), 0, dp(8))
        }
        parent.addView(t)
    }

    private fun toggleCard(parent: LinearLayout, name: String, description: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), dp(13), dp(12), dp(13))
            setBackgroundColor(card)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply {
            text = name; textSize = 14f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val detail = TextView(this).apply {
            text = description; textSize = 10f; setTextColor(muted)
            setPadding(0, dp(4), dp(6), 0)
        }
        texts.addView(heading); texts.addView(detail)
        box.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            buttonTintList = android.content.res.ColorStateList.valueOf(red)
            isChecked = false
            setOnCheckedChangeListener { _, checked ->
                Toast.makeText(this@MainActivity,
                    if (checked) "$name: demonstração ligada" else "$name: desligada",
                    Toast.LENGTH_SHORT).show()
            }
        }
        box.addView(sw)
        parent.addView(box, params(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun params(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
